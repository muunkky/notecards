import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react({
    jsxRuntime: 'classic'
  })],
  server: {
    host: '127.0.0.1',
    port: 5174
  },
  preview: {
    port: 4173
  }
})
